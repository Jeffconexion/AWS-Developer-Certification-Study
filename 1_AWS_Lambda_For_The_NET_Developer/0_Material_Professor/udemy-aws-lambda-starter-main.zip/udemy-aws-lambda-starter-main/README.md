# AWS Lambda For The .NET Developer

Source code samples used for the course published on Udemy - AWS Lambda For The .NET Developer

You can check out the course 

👉 [Udemy](https://www.udemy.com/course/aws-lambda-dotnet/?referralCode=981481B991C2890BD448)      
👉 [Gumroad](https://rahulpnath.gumroad.com/l/aws-lambda-dot-net) 


## Other Resources
- [A CDK Companion for Rahul Nath's .NET Lambda Course](https://scottie.is/writing/a-cdk-companion-for-the-rahul-nath-lambda-course/) by [@scottenriquez](https://github.com/scottenriquez/rahul-nath-dotnet-lambda-course-cdk-companion)
